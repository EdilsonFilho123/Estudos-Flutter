import 'package:filmes_app/core/rest_client/rest_client.dart';
import 'package:filmes_app/core/rest_client/rest_client_dio.dart';
import 'package:filmes_app/core/rest_client/rest_client_http.dart';
import 'package:filmes_app/repositories/movies/movies_repository.dart';
import 'package:filmes_app/repositories/movies/movies_repository_custom_dio_impl.dart';
import 'package:filmes_app/repositories/movies/movies_repository_impl.dart';
import 'package:filmes_app/repositories/movies/movies_repository_res_client.dart';
import 'package:get/get.dart';
import './movies_controller.dart';

class MoviesBindings implements Bindings {
  @override
  void dependencies() {
    Get.create<RestClient>(() => RestClientDio());
    // Get.lazyPut<RestClient>(() => RestClientHttp());
    // Get.lazyPut<MoviesRepository>(() => MoviesRepositoryImpl());
    // Get.lazyPut<MoviesRepository>(() => MoviesRepositoryCustomDioImpl());
    Get.lazyPut<MoviesRepository>(
        () => MoviesRepositoryRestClient(restClient: Get.find()));
    Get.put(MoviesController());
  }
}
