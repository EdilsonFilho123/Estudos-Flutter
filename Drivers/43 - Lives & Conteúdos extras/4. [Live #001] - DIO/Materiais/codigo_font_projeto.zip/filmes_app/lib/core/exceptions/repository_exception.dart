
class RepositoryException implements Exception {
  
}