package br.com.academiadoflutter.filmes_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
